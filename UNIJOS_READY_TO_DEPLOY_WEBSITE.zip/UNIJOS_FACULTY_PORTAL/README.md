
UNIJOS FACULTY PORTAL – READY TO DEPLOY

Created by Mafat Toff

BACKEND:
cd server
npm install
npm start

FRONTEND:
cd client
npm install
npm run build

Deploy backend on Render/Railway.
Deploy frontend build folder on Vercel.
