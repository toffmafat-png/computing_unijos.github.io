
import React from "react";
import ReactDOM from "react-dom/client";

ReactDOM.createRoot(document.getElementById("root")).render(
  <h1 style={{textAlign:"center",marginTop:"40px"}}>
    UNIJOS Faculty Portal<br/>
    <small>Created by Mafat Toff</small>
  </h1>
);
