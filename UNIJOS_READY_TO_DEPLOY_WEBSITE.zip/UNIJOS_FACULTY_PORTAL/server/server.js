
/*
 UNIJOS Faculty Portal
 Created by Mafat Toff
 Production Ready Backend
*/

import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import http from "http";
import { Server } from "socket.io";

const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());

app.use(rateLimit({ windowMs: 15*60*1000, max: 100 }));

mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/unijosFacultyDB")
  .then(()=>console.log("MongoDB Connected"));

const server = http.createServer(app);
const io = new Server(server, { cors:{origin:"*"} });

io.on("connection", socket => {
  socket.on("sendMessage", msg => io.emit("receiveMessage", msg));
});

app.get("/", (req,res)=>{
  res.json({status:"UNIJOS Faculty Portal Backend Running"});
});

server.listen(process.env.PORT || 5000, ()=>{
  console.log("Server running");
});
